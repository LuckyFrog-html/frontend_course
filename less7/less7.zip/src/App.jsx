import { useState } from "react"
import Button from "./componets/Button/Button"
import "./app.css"

const App = () => {
  const [count, setCount] = useState(5)
  
  return <div className="container">
    <p className="text">Наша переменная: {count % 2 === 1 ? count * 1000 : count}</p>
    <Button text="боба инкремент" onClick={() => setCount(prev => prev + 1)} />
    <Button text="боба декремент" onClick={() => setCount(prev => Math.max(0, prev - 1))} />
  </div>
}

export default App